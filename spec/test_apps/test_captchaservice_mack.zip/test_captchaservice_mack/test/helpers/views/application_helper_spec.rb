require File.join(File.dirname(__FILE__), '..', '..', 'spec_helper')

describe Mack::ViewHelpers::ApplicationHelper do
  include Mack::ViewHelpers
  
end

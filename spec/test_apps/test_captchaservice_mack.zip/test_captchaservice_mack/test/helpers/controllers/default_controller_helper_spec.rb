require File.join(File.dirname(__FILE__), '..', '..', 'spec_helper')

describe Mack::ControllerHelpers::DefaultController do
  include Mack::ControllerHelpers::DefaultController
  
end

Mack::Routes.build do |r|
  
  r.home_page "/", :controller => :default, :action => :index
  r.show_captcha_configuration "/show_captcha_configuration", :controller => :default, :action => :show_captcha_configuration
  r.show_captcha "/show_captcha", :controller => :default, :action => :show_captcha
  r.verify_captcha '/verify_captcha', :controller => :default, :action => :verify_captcha
  r.defaults
  
end

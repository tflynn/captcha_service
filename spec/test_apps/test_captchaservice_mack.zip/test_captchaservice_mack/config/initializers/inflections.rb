# You can define your own rules for the Inflector here.
Mack::Utils::Inflector.inflections do |inflect|

  # Example of defining a plural rule:
  # inflect.plural('ox', 'oxen')

  # Example of defining a singular rule:
  # inflect.singular('oxen', 'ox')

  # Example of defining an 'irregular' rule:
  # inflect.irregular('person', 'people')
  
end

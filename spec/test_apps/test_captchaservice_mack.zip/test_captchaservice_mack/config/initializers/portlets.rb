# Using this file you can Portlets to your application. 
# Portlets are Mack applications that have been packaged as Gems using
# a few simple Rake tasks. These Portlets can extend your application
# and bring new functionality to them very, very easily.
require_portlets do |p|
  # examples:
  # p.add :my_cool_portlet, :version => "1.2.2"
  # p.add :my_cool_portlet, :source => "http://gems.rubyforge.org"
end

# Register mime types for a file extension in this file.
# 
# Example:
# Mack::Utils::MimeTypes.register(:iphone, "app/iphone")

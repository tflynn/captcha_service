# This controller has been generated so we can give you a 'pretty' and dynamic welcome page.
# You are under no obligation to extend from this controller, as some other frameworks would
# you too. :) If you do decide to extend this controller, you'll be happy to know that it
# will get loaded first, before your other controllers, so it will be present for their use.
class DefaultController
  include Mack::Controller
  
  require 'rubygems'
  gem 'captcha_service','0.0.2'
  require 'captcha_service'
  
  # '/'
  # Note: You do not need to actually have an empty action like this defined for Mack to
  # find the view on disk. This is only included here for the sake of 'completeness'.
  def index
  end

  def show_captcha_configuration
    captcha_configuration = CaptchaService::Configurator.get_configuration
    render(:text, captcha_configuration.inspect)
  end

  def show_captcha
    provider = CaptchaService::Configurator.get_provider
    @captcha_key, @captcha_image_tag = provider.image_tag
    @verify_captcha_url = verify_captcha_url
    @show_captcha_url = show_captcha_url
  end
  
  def verify_captcha
    provider = CaptchaService::Configurator.get_provider
    captcha_key = params[:captcha_key]
    captcha_answer = params[:captcha_answer]
    @answer = provider.verify_answer(captcha_key,captcha_answer)
    @show_captcha_url = show_captcha_url
  end
  
end

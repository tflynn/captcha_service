module Mack
  module ControllerHelpers
    module DefaultController
      # Anything in this module will be included into the DefaultController as protected methods.
    end
  end
end
